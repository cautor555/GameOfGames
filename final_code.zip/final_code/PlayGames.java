/**
 * PlayGames main application for testing and running Game of Games
 *
 * @author Rakan AlZagha, Wayne Sassano, Christian Autor, and Min Jie Teh
 * @version final version
 */

import java.util.*;

public class PlayGames { //class

  /**
    * main method
    *
    * @param  String args[]
    * @return n/a
    */

  public static void main(String args[]) {
    Scoreboard scoreboard = new Scoreboard();

    GetInput getInput = new GetInput();

    scoreboard.printboard();

    GuessTheNumber game = new GuessTheNumber();
    game.guessTheNumberMain(scoreboard, getInput);

    scoreboard.printboard();
  }
}
