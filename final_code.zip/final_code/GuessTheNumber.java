/**
 * GuessTheNumber game from game of games
 *
 * @author Rakan AlZagha
 * @version final version
 */

import java.util.*;

public class GuessTheNumber extends Game { //class
  private String gameName = "Guess the Number";
  private String rules = "Rules: The computer will set the range of a number and number of guesses. The computer will then think of a number within the given range. The player guessing will then be given the range and number of guesses they get to guess the number. If you guess the number within the given number of guesses you win, otherwise you lose.";
  private String winGameOutput = "\nWin!";
  private String tryAgainOutput = "Try again!\n";
  private String loseGameOutput = "\nComputer wins, you lose.";
  private String guessNumberOutput = "Pick a number within the range:";
  private String errorguessNumberOutput = "Guess not within range:";
  private int maxRange = 100;
  private int compRange;
  private int numGuesses; //best out of abstract
  private int guessingNumber; //get number in range abstract
  private int playerGuess;
  private int guessesTaken;

  /**
    * guessTheNumberMain method
    *
    * @param  Scoreboard scoreboard, GetInput getInput
    * @return none
    */

  public void guessTheNumberMain(Scoreboard scoreboard, GetInput getInput) {
      displayRules(gameName, rules);

      playerScore = opponentScore = 0;

      compRange = getNumberInRange(maxRange);

      numGuesses = getNumberInRange(compRange/2);
      setBestOf(numGuesses);

      guessingNumber = getNumberInRange(compRange);

      displayRangeAndGuess(compRange, bestOf);

      guessesTaken = 1;

      while(guessesTaken < maxRange){
          playerGuess = getInput.getPlayerIntInput(guessNumberOutput, errorguessNumberOutput, compRange);
          if(checkAnswer(playerGuess, guessingNumber)){
              System.out.println(winGameOutput);
              playerScoresAPoint();
              guessesTaken++;
              break;
          }
          else{
              if(guessesTaken < bestOf){
                System.out.println(tryAgainOutput);
                guessesTaken = guessesTaken + 1;
                continue;
              }
              else{
                opponentScoresAPoint();
                System.out.println(loseGameOutput);
                break;
              }
          }
      }

    if(getPlayerScore() == 1){
      scoreboard.incrementScore(1);
    }
    else{
      scoreboard.incrementScore(0);
    }
  }

  /**
    * displayRangeAndGuess method
    *
    * @param  int range, int guesses
    * @return none
    */

  public void displayRangeAndGuess(int range, int guesses) {
    System.out.println("\nRange is 1 : " + range);
    System.out.println("Guesses: " + guesses + "\n");
  }

  /**
    * numInRange method
    *
    * @param  int guess, int compRange
    * @return boolean
    */

  public boolean numInRange(int guess, int compRange) {
      if(guess <= compRange) {
          return true;
      }
      else {
          return false;
      }
  }

  /**
    * checkAnswer abstract method
    *
    * @param  T guess, T answer
    * @return boolean
    */

  protected <T> boolean checkAnswer(T guess, T answer) {
    if(guess == answer)
      return true;
    return false;
  }

}
