/**
 * RedThread game from game of games
 *
 * @author Christian Autor
 * @version final version
 */

import java.util.*;

public class RedThread extends Game { //class
  private final int PLAYER_CODE = 1;
  private final int COMPUTER_CODE = 0;
  private final int GUESS_PLACEHOLDER = -1;
  private final int TOTAL_SPOOLS = 20;
  private final String gameName = "Find The Red Thread";
  private final String rules = "Players pick the number of spools to be removed at a time and then take turns taking n spools until one finds the red spool";
  private final String messages[] = {"How many spools would you like to pick up at a time; 1-10", "Enter a spool number", "Computer is takin a turn", "You Win", "You Lose"};
  private final String errorMsgs[] = {"Invalid input, please enter an integer between 1-10", "Spool has already been picked. Please chose a number that has not yet been chosen"};
  private final String sortedSpoolColors[] = {"Orange", "Yellow", "Green", "Blue", "Indigo", "Violet", "Black", "White", "Brown", "Grey", "Maroon"};
  private final String redSpoolStr = "Red";
  private final String TAKEN_SPOOL = "Taken";
  private String unsortedSpoolColors[] = new String[TOTAL_SPOOLS];
  private int maxSpoolRemoval;
  private int redSpool;
  private int[] playerGuesses, computerGuesses;

  /**
    * redThreadMain method
    *
    * @param  Scoreboard scoreboard, GetInput getInput
    * @return none
    */

  public void redThreadMain(Scoreboard scoreboard, GetInput getInput) {
    displayRules(gameName, rules);
    playerScore = opponentScore = 0;

    maxSpoolRemoval = getInput.getPlayerIntInput(messages[0], errorMsgs[0], TOTAL_SPOOLS/2);

    playerGuesses = new int[maxSpoolRemoval];
    computerGuesses = new int[maxSpoolRemoval];
    Arrays.fill(playerGuesses, GUESS_PLACEHOLDER);
    Arrays.fill(computerGuesses, GUESS_PLACEHOLDER);

    redSpool = getNumberInRange(TOTAL_SPOOLS-1);
    unsortedSpoolColors[redSpool] = redSpoolStr;

    for(int i = 0; i<TOTAL_SPOOLS; i++) {
      if(i != redSpool)
        unsortedSpoolColors[i] = sortedSpoolColors[getNumberInRange(sortedSpoolColors.length)-1];
    }

    while(!(playerScore>bestOf/2 || opponentScore>bestOf/2)) {
      displaySpools();
      Arrays.fill(playerGuesses, GUESS_PLACEHOLDER);
      Arrays.fill(computerGuesses, GUESS_PLACEHOLDER);

      for(int i = 0; i<maxSpoolRemoval; i++) {
        playerGuesses[i] = getInput.getPlayerIntInput(messages[1], messages[1], TOTAL_SPOOLS) -1;
        while(!(guessIsValid(playerGuesses[i])))
          playerGuesses[i] = getInput.getPlayerIntInput(errorMsgs[1], messages[1], TOTAL_SPOOLS) -1;
      }

      printGuesses(playerGuesses);
      if(checkGuesses(playerGuesses, redSpool)) {
        playerScoresAPoint();
        printWin(true);
        break;
      }

      System.out.println(messages[2]);
      try
      { Thread.sleep(2500); }
      catch (Exception e) { }

      for(int i = 0; i<maxSpoolRemoval; i++) {
        while(!guessIsValid(computerGuesses[i]))
          computerGuesses[i] = getNumberInRange(TOTAL_SPOOLS-1);
      }

      printGuesses(computerGuesses);
      if(checkGuesses(computerGuesses, redSpool))
      {
        opponentScoresAPoint();
        printWin(false);
        break;
      }

    }
    if(playerScore > opponentScore)
      scoreboard.incrementScore(PLAYER_CODE);
    else
      scoreboard.incrementScore(COMPUTER_CODE);
  }

  /**
    * displaySpools method
    *
    * @param  none
    * @return none
    */

  private void displaySpools() {
    System.out.print("\n");
    for(int i = 0; i<unsortedSpoolColors.length; i++) {
      if(unsortedSpoolColors[i].equals(TAKEN_SPOOL))
        System.out.print(unsortedSpoolColors[i] + " | ");
      else
        System.out.print(i+1 + " | ");
    }
    System.out.println("\n\n");
  }

  /**
    * guessIsValid method
    *
    * @param  int guess
    * @return boolean
    */

  private boolean guessIsValid(int guess) {
    if(guess == GUESS_PLACEHOLDER)
      return false;
    else if(unsortedSpoolColors[guess].equals(TAKEN_SPOOL))
      return false;
    return true;
  }

  /**
    * printGuesses method
    *
    * @param  int[] guess
    * @return none
    */

  private void printGuesses(int[] guess) {
    System.out.print("\nGuesses\n");
    for(int i = 0; i<guess.length; i++)
      System.out.print(unsortedSpoolColors[guess[i]] + " | ");
    System.out.print("\n\n");
  }

  /**
    * checkGuesses method
    *
    * @param  int[] guess, int answer
    * @return boolean
    */

  protected boolean checkGuesses(int[] guess, int answer) {
    boolean win = false;
    for(int i = 0; i<guess.length; i++) {
      if(checkAnswer(guess[i], answer))
        win = true;
      else
        unsortedSpoolColors[guess[i]] = TAKEN_SPOOL;
    }
    return win;
  }

  /**
    * checkAnswer method
    *
    * @param  T guess, T answer
    * @return boolean
    */

  protected <T> boolean checkAnswer(T guess, T answer) {
    if(guess == answer)
      return true;
    return false;
  }

  /**
    * printWin method
    *
    * @param  boolean win
    * @return none
    */

  protected void printWin(boolean win) {
    if(win)
      System.out.println("\n\n " + messages[3] + gameName);
    else
      System.out.println("\n\n " + messages[4] + gameName);
  }

}
