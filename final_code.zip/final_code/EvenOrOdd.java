/**
 * EvenOrOdd game from game of games
 *
 * @author Rakan AlZagha
 * @version final version
 */

import java.util.*;

public class EvenOrOdd extends Game { //class
  private String gameName = "Even and Odd";
  private String rules = "In this game, you choose to be either the odd player or the even player. Then, you and the computer both choose a number between 1 and 5. The two numbers are added. If the sum of the numbers is odd, the odd player wins. If the sum of numbers is even, the even player wins. You can choose how many rounds will be played to determine a winner. Goodluck!";
  private String bestOfOutput = "Input best-of number (must be an odd number)";
  private String errorBestOfOutput = "Invalid input, please enter a valid odd number";
  private String evenOrOddOutput = "Input odd to be odd player or even to be even player and press enter";
  private String errorEvenOrOddOutput =  "Invalid input, please enter odd or even";
  private String playerThrowOutput = "Input number from 1 to 5 and press enter";
  private String errorPlayerThrowOutput = "Invalid input, please enter a number from 1 to 5";
  private String winRoundOutput = "You win this round!\n";
  private String loseRoundOutput = "You lost this round!\n";
  private String winGameOutput = "You win the game!";
  private String loseGameOutput = "You lose the game!";
  private int maxInput = 5;
  private int bestOutOfNum;
  private int sum;
  private String playerChoice;
  private int playerThrow;
  private int compThrow;

  /**
    * evenOrOddMain method
    *
    * @param  Scoreboard scoreboard, GetInput getInput
    * @return none
    */

  public void evenOrOddMain(Scoreboard scoreboard, GetInput getInput) {
      displayRules(gameName, rules);

      playerScore = opponentScore = 0;

      bestOutOfNum = getInput.getPlayerIntInputOdd(bestOfOutput, errorBestOfOutput);
      setBestOf(bestOutOfNum);

      String validAnswers[] = {"even", "odd"};
      String playerChoice = getInput.getPlayerStringInput(evenOrOddOutput, errorEvenOrOddOutput, validAnswers);

      while(playerScore <= bestOf/2 && opponentScore <= bestOf/2) {
        compThrow = getNumberInRange(maxInput);

        int playerThrow = getInput.getPlayerIntInput(playerThrowOutput, errorPlayerThrowOutput, maxInput);

        if(throwInRange(playerThrow, maxInput)) {
            setPlayerThrow(playerThrow);
            sumOfThrows(playerThrow, compThrow);
            System.out.println("\nPlayer Choice: " + playerChoice + "\nYour Throw: " + playerThrow + "\nSum of Throws: " + sum);
            if (playerChoice.equals("even") && (sum % 2 == 0)) {
                playerScoresAPoint();
                System.out.println(winRoundOutput);
            }
            else if (playerChoice.equals("odd") && (sum % 2 != 0)) {
                playerScoresAPoint();
                System.out.println(winRoundOutput);
            }
            else {
                opponentScoresAPoint();
                System.out.println(loseRoundOutput);
            }
        }
      }

      if(getPlayerScore() > bestOf/2){
          System.out.println(winGameOutput);
          scoreboard.incrementScore(1);
      }

      else if(getOpponentScore() > bestOf/2){
        System.out.println(loseGameOutput);
        scoreboard.incrementScore(0);
      }
  }

  /**
    * throwInRange method
    *
    * @param  int guess, int maxInput
    * @return boolean
    */

  public boolean throwInRange(int guess, int maxInput) {
      if(guess <= maxInput) {
          return true;
      }
      else {
          return false;
      }
  }

  /**
    * setPlayerChoice method
    *
    * @param  String choice
    * @return none
    */

  public void setPlayerChoice(String choice) {
      playerChoice = choice;
  }

  /**
    * getPlayerChoice method
    *
    * @param  none
    * @return playerChoice
    */

  public String getPlayerChoice() {
      return playerChoice;
  }

  /**
    * setPlayerThrow method
    *
    * @param  int guess
    * @return none
    */

  public void setPlayerThrow(int guess) {
      playerThrow = guess;
  }

  /**
    * sumOfThrows method
    *
    * @param  int playerThrow, int compThrow
    * @return sum
    */

  public int sumOfThrows(int playerThrow, int compThrow) {
      sum = playerThrow + compThrow;
      return sum;
  }

  /**
    * getSum method
    *
    * @param  none
    * @return sum
    */

  public int getSum() {
      return sum;
  }

  /**
    * checkAnswer abstract method
    *
    * @param  T guess, T answer
    * @return boolean
    */

  protected <T> boolean checkAnswer(T guess, T answer) {
    if(guess == answer)
      return true;
    return false;
  }
}
