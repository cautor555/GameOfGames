/**
 * FindTheThimble game from game of games
 *
 * @author Min Jie Teh
 * @version final version
 */

import java.util.*;

public class FindTheThimble extends Game { //class
  private int maxGuess = 2;
  private String userGuess = "";
  private String rightAnswer = "";
  private String rightGuessMsg = "You guessed right";
  private String wrongGuessMsg = "You guessed wrong";
  private String userWonMsg = "You Win!";;
  private String userLostMsg = "You Lose!";
  private String gameName = "Find The Thimble";
  private String gameRules = "The computer will hide a thimble in either the left hand or right hand. You must guess a hand. If you guess correctly, you win the round. If you guess wrong, you lose the round.";
  private String bestOfPrompt = "Enter a number of rounds to play best out of: ";
  private String bestOfErrorMsg = "Please enter an odd number";
  private String userGuessPrompt = "Enter L or R to pick a guess: ";
  private String userGuessErrorMsg = "Please enter L or R";
  private String validAnswers[] = {"L", "R", "l", "r"};

  /**
    * FindTheThimbleMain method
    *
    * @param  Scoreboard scoreboard, GetInput getInput
    * @return none
    */

  public void FindTheThimbleMain(Scoreboard scoreboard, GetInput getInput) {
    displayRules(gameName, gameRules);

    bestOf = getInput.getPlayerIntInputOdd(bestOfPrompt, bestOfErrorMsg);

    playerScore = opponentScore = 0;

    while (!(playerScore>bestOf/2) && !(opponentScore>bestOf/2)){
      hideTheThimble();
      userGuess = getInput.getPlayerStringInput(userGuessPrompt, userGuessErrorMsg, validAnswers);

      if (checkAnswer(userGuess, rightAnswer)) {
        System.out.println(rightGuessMsg);
        playerScoresAPoint();
      }
      else {
        System.out.println(wrongGuessMsg);
        opponentScoresAPoint();
      }

    }

    if (playerScore>opponentScore) {
      System.out.println(userWonMsg);
      scoreboard.incrementScore(1);
    }
    else {
      System.out.println(userLostMsg);
      scoreboard.incrementScore(0);
    }

  }

  /**
    * hideTheThimble method
    *
    * @param  none
    * @return none
    */

  private void hideTheThimble() {
    int hide = 0;
    if (getNumberInRange(maxGuess)==1)
      rightAnswer = "L";
    else
      rightAnswer = "R";
  }


  /**
    * checkAnswer abstract method
    *
    * @param  T guess, T answer
    * @return boolean
    */

  protected <T> boolean checkAnswer(T guess, T answer) {
    if(guess == answer)
			return true;
    else
      return false;
  }

}
